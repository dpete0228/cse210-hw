using System;

class KingMan : Warrior
{


   public KingMan():base("King Man", 100, 20, 30, 60){

   }



}