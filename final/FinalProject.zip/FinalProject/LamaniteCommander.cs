using System;

class LamaniteCommander : Warrior
{


   public LamaniteCommander():base("Lamanite Commander", 100, 15, 7, 40){

   }
}