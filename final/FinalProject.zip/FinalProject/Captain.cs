using System;

class Captain : Warrior
{


   public Captain():base("Captain", 150, 30, 20, 75){

   }



}