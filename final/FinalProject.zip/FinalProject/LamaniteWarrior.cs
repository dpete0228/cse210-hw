using System;

class LamaniteWarrior : Warrior
{


   public LamaniteWarrior():base("Lamanite Warrior", 100, 15, 7, 40){

   }
}